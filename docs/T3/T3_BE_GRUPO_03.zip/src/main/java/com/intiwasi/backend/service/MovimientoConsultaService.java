package com.intiwasi.backend.service;

import com.intiwasi.backend.dto.inventario.MovimientoConsultaResponse;
import com.intiwasi.backend.dto.inventario.ResponsableMovimientoResponse;
import com.intiwasi.backend.dto.inventario.ProductoMovimientoResponse;
import com.intiwasi.backend.entity.KardexMovimiento;
import com.intiwasi.backend.entity.enums.TipoDocumento;
import com.intiwasi.backend.exception.RecursoNoEncontradoException;
import com.intiwasi.backend.repository.KardexRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.time.LocalDateTime;

@Service
@RequiredArgsConstructor
public class MovimientoConsultaService {
    private final KardexRepository kardexRepository;

    @Transactional(readOnly = true)
    public java.util.List<ResponsableMovimientoResponse> responsables() {
        return kardexRepository.listarResponsables().stream()
                .map(fila -> new ResponsableMovimientoResponse((Integer) fila[0], (String) fila[1]))
                .toList();
    }

    @Transactional(readOnly = true)
    public java.util.List<ProductoMovimientoResponse> productos() {
        return kardexRepository.listarProductos().stream()
                .map(fila -> new ProductoMovimientoResponse((Integer) fila[0],
                        (String) fila[1], (String) fila[2]))
                .toList();
    }

    @Transactional(readOnly = true)
    public Page<MovimientoConsultaResponse> consultar(
            LocalDate fechaInicial,
            LocalDate fechaFinal,
            Integer idProducto,
            TipoDocumento tipoDocumento,
            Integer idUsuario,
            Pageable pageable) {
        validarRango(fechaInicial, fechaFinal);
        LocalDateTime inicio = fechaInicial == null ? null : fechaInicial.atStartOfDay();
        LocalDateTime finExclusivo = fechaFinal == null ? null : fechaFinal.plusDays(1).atStartOfDay();
        return kardexRepository.buscar(inicio, finExclusivo, idProducto, tipoDocumento, idUsuario, pageable)
                .map(this::convertir);
    }

    @Transactional(readOnly = true)
    public MovimientoConsultaResponse obtener(Integer id) {
        return kardexRepository.findById(id).map(this::convertir)
                .orElseThrow(() -> new RecursoNoEncontradoException("Movimiento no encontrado con ID: " + id));
    }

    private void validarRango(LocalDate inicio, LocalDate fin) {
        if (inicio != null && fin != null && inicio.isAfter(fin)) {
            throw new IllegalArgumentException("La fecha inicial no puede ser posterior a la fecha final");
        }
    }

    private MovimientoConsultaResponse convertir(KardexMovimiento k) {
        return MovimientoConsultaResponse.builder()
                .idMovimiento(k.getIdMovimiento()).idDocumento(k.getIdDocumento())
                .idDocumentoOrigen(k.getIdDocumentoOrigen()).estadoDocumento(k.getEstadoDocumento())
                .tipoDocumento(k.getTipoDocumento()).fechaEmision(k.getFechaEmision())
                .idUsuario(k.getIdUsuario()).usuarioResponsable(k.getUsuarioResponsable())
                .idProducto(k.getIdProducto()).sku(k.getSku()).nomProducto(k.getNomProducto())
                .nomCategoria(k.getNomCategoria()).cantidad(k.getCantidad())
                .cantidadConSigno(k.getCantidadConSigno()).motivo(k.getMotivo())
                .idOrden(k.getIdOrden()).numeroGuiaRemision(k.getNumeroGuiaRemision()).build();
    }
}
