package com.intiwasi.backend.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;

@Data
@Entity
@Table(name = "Proveedores")
public class Proveedor {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "IdProveedor")
    private Integer idProveedor;

    @Column(name = "NomProveedor", length = 100, nullable = false)
    private String nomProveedor;

    @Column(name = "PrefijoGuia", length = 30, unique = true)
    private String prefijoGuia;

    @Column(name = "RUC", length = 11, nullable = false, unique = true)
    private String ruc;

    @Column(name = "Contacto", length = 100)
    private String contacto;

    @Column(name = "Telefono", length = 20, nullable = false)
    private String telefono;

    @Column(name = "Direccion", length = 150)
    private String direccion;

    @Column(name = "Estado", nullable = false)
    private Byte estado = (byte) 1;
}