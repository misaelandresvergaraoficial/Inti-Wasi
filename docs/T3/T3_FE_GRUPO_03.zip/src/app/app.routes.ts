import { Routes } from '@angular/router';
import { adminGuard, authGuard, changesGuard, guestGuard, landingRedirect } from './core/guards';

export const routes: Routes = [
  {
    path: 'login',
    title: 'Iniciar sesión · Inti Wasi',
    canActivate: [guestGuard],
    loadComponent: () => import('./features/auth/login').then((m) => m.Login),
  },
  {
    path: '',
    canActivate: [authGuard],
    canActivateChild: [authGuard],
    loadComponent: () => import('./layout/shell').then((m) => m.Shell),
    children: [
      {
        path: 'inicio',
        redirectTo: landingRedirect,
      },
      {
        path: 'usuarios',
        title: 'Usuarios · Inti Wasi',
        canActivate: [adminGuard],
        loadComponent: () => import('./features/users/users-list').then((m) => m.UsersList),
      },
      {
        path: 'dashboard',
        title: 'Dashboard · Inti Wasi',
        canActivate: [adminGuard],
        loadComponent: () => import('./features/dashboard/dashboard').then((m) => m.Dashboard),
      },
      {
        path: 'reportes',
        title: 'Reportes · Inti Wasi',
        canActivate: [adminGuard],
        loadComponent: () => import('./features/reports/reports').then((m) => m.Reports),
      },
      {
        path: 'usuarios/nuevo',
        title: 'Crear usuario · Inti Wasi',
        canActivate: [adminGuard],
        canDeactivate: [changesGuard],
        loadComponent: () => import('./features/users/user-form').then((m) => m.UserForm),
      },
      {
        path: 'usuarios/:id/editar',
        title: 'Editar usuario · Inti Wasi',
        canActivate: [adminGuard],
        canDeactivate: [changesGuard],
        loadComponent: () => import('./features/users/user-form').then((m) => m.UserForm),
      },
      {
        path: 'ordenes-compra',
        title: 'Órdenes de compra · Inti Wasi',
        loadComponent: () => import('./features/orders/orders-list').then((m) => m.OrdersList),
      },
      {
        path: 'entradas',
        title: 'Entradas · Inti Wasi',
        loadComponent: () =>
          import('./features/entradas/entradas-list').then((m) => m.EntradasList),
      },
      {
        path: 'entradas/nueva',
        title: 'Registrar entrada · Inti Wasi',
        canDeactivate: [changesGuard],
        loadComponent: () => import('./features/entradas/entrada-form').then((m) => m.EntradaForm),
      },
      {
        path: 'entradas/:id/editar',
        title: 'Rectificar entrada · Inti Wasi',
        canDeactivate: [changesGuard],
        loadComponent: () => import('./features/entradas/entrada-form').then((m) => m.EntradaForm),
      },
      {
        path: 'entradas/:id',
        title: 'Detalle de entrada · Inti Wasi',
        loadComponent: () =>
          import('./features/entradas/entrada-detail').then((m) => m.EntradaDetail),
      },
      {
        path: 'salidas',
        title: 'Salidas · Inti Wasi',
        loadComponent: () => import('./features/salidas/salidas-list').then((m) => m.SalidasList),
      },
      {
        path: 'salidas/nueva',
        title: 'Registrar salida · Inti Wasi',
        canDeactivate: [changesGuard],
        loadComponent: () => import('./features/salidas/salida-form').then((m) => m.SalidaForm),
      },
      {
        path: 'salidas/:id/editar',
        title: 'Rectificar salida · Inti Wasi',
        canDeactivate: [changesGuard],
        loadComponent: () => import('./features/salidas/salida-form').then((m) => m.SalidaForm),
      },
      {
        path: 'salidas/:id',
        title: 'Detalle de salida · Inti Wasi',
        loadComponent: () => import('./features/salidas/salida-detail').then((m) => m.SalidaDetail),
      },
      {
        path: 'ajustes',
        title: 'Ajustes · Inti Wasi',
        canActivate: [adminGuard],
        loadComponent: () => import('./features/ajustes/ajustes-list').then((m) => m.AjustesList),
      },
      {
        path: 'ajustes/nuevo',
        title: 'Registrar ajuste · Inti Wasi',
        canActivate: [adminGuard],
        canDeactivate: [changesGuard],
        loadComponent: () => import('./features/ajustes/ajuste-form').then((m) => m.AjusteForm),
      },
      {
        path: 'ajustes/:id/editar',
        title: 'Rectificar ajuste · Inti Wasi',
        canActivate: [adminGuard],
        canDeactivate: [changesGuard],
        loadComponent: () => import('./features/ajustes/ajuste-form').then((m) => m.AjusteForm),
      },
      {
        path: 'ajustes/:id',
        title: 'Detalle de ajuste · Inti Wasi',
        canActivate: [adminGuard],
        loadComponent: () => import('./features/ajustes/ajuste-detail').then((m) => m.AjusteDetail),
      },
      {
        path: 'documentos',
        title: 'Documentos · Inti Wasi',
        loadComponent: () =>
          import('./features/documentos/documentos-list').then((m) => m.DocumentosList),
      },
      {
        path: 'documentos/:id',
        title: 'Detalle de documento · Inti Wasi',
        loadComponent: () =>
          import('./features/documentos/documento-detail').then((m) => m.DocumentoDetail),
      },
      {
        path: 'movimientos',
        title: 'Movimientos · Inti Wasi',
        loadComponent: () =>
          import('./features/movimientos/movimientos-list').then((m) => m.MovimientosList),
      },
      {
        path: 'movimientos/:id',
        title: 'Detalle de movimiento · Inti Wasi',
        loadComponent: () =>
          import('./features/movimientos/movimiento-detail').then((m) => m.MovimientoDetail),
      },
      {
        path: 'ordenes-compra/nueva',
        title: 'Crear orden de compra · Inti Wasi',
        canActivate: [adminGuard],
        canDeactivate: [changesGuard],
        loadComponent: () => import('./features/orders/order-form').then((m) => m.OrderForm),
      },
      {
        path: 'ordenes-compra/:id/editar',
        title: 'Editar orden de compra · Inti Wasi',
        canActivate: [adminGuard],
        canDeactivate: [changesGuard],
        loadComponent: () => import('./features/orders/order-form').then((m) => m.OrderForm),
      },
      {
        path: 'ordenes-compra/:id',
        title: 'Detalle de orden de compra · Inti Wasi',
        loadComponent: () => import('./features/orders/order-detail').then((m) => m.OrderDetail),
      },
      {
        path: 'acceso-denegado',
        title: 'Acceso restringido · Inti Wasi',
        loadComponent: () => import('./features/auth/access-denied').then((m) => m.AccessDenied),
      },
      {
        path: 'proveedores',
        title: 'Proveedores · Inti Wasi',
        loadComponent: () =>
          import('./features/proveedores/proveedores-list').then((m) => m.ProveedoresList),
      },
      {
        path: 'proveedores/nuevo',
        title: 'Crear proveedor · Inti Wasi',
        canActivate: [adminGuard],
        canDeactivate: [changesGuard],
        loadComponent: () =>
          import('./features/proveedores/proveedor-form').then((m) => m.ProveedorForm),
      },
      {
        path: 'proveedores/:id/editar',
        title: 'Editar proveedor · Inti Wasi',
        canActivate: [adminGuard],
        canDeactivate: [changesGuard],
        loadComponent: () =>
          import('./features/proveedores/proveedor-form').then((m) => m.ProveedorForm),
      },
      {
        path: 'categorias',
        title: 'Categorías · Inti Wasi',
        canActivate: [adminGuard],
        loadComponent: () =>
          import('./features/categorias/categorias').then((m) => m.CategoriasList),
      },
      {
        path: 'categorias/nuevo',
        title: 'Crear categoría · Inti Wasi',
        canActivate: [adminGuard],
        canDeactivate: [changesGuard],
        loadComponent: () =>
          import('./features/categorias/categoria-form').then((m) => m.CategoriaForm),
      },
      {
        path: 'categorias/:id/editar',
        title: 'Editar categoría · Inti Wasi',
        canActivate: [adminGuard],
        canDeactivate: [changesGuard],
        loadComponent: () =>
          import('./features/categorias/categoria-form').then((m) => m.CategoriaForm),
      },
      {
        path: 'productos',
        title: 'Productos · Inti Wasi',
        loadComponent: () =>
          import('./features/productos/productos-list').then((m) => m.ProductosList),
      },
      {
        path: 'productos/nuevo',
        title: 'Crear producto · Inti Wasi',
        canActivate: [adminGuard],
        canDeactivate: [changesGuard],
        loadComponent: () =>
          import('./features/productos/producto-form').then((m) => m.ProductoForm),
      },
      {
        path: 'productos/stock-bajo',
        title: 'Stock Bajo · Inti Wasi',
        canActivate: [adminGuard],
        loadComponent: () =>
          import('./features/productos/stock-bajo-list').then((m) => m.StockBajoList),
      },
      {
        path: 'productos/:id/editar',
        title: 'Editar producto · Inti Wasi',
        canActivate: [adminGuard],
        canDeactivate: [changesGuard],
        loadComponent: () =>
          import('./features/productos/producto-form').then((m) => m.ProductoForm),
      },

      { path: '', pathMatch: 'full', redirectTo: landingRedirect },
      { path: '**', redirectTo: landingRedirect },
    ],
  },
];
