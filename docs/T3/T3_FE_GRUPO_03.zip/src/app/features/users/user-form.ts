import { Component, ElementRef, inject, signal, viewChild } from '@angular/core';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { AbstractControl, FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { ActivatedRoute, Router, RouterLink } from '@angular/router';
import { MatButtonModule } from '@angular/material/button';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatDialog } from '@angular/material/dialog';
import { firstValueFrom } from 'rxjs';
import { UsersService } from '../../core/users.service';
import { AuthService } from '../../core/auth.service';
import { NoticeService } from '../../core/notice.service';
import { ApiRequestError, Rol } from '../../core/models';
import { PendingChanges } from '../../core/guards';
import { ConfirmDialog } from '../../shared/confirm-dialog';
import { fieldError, focusFirstInvalid } from '../../shared/form-errors';
import { Icon } from '../../shared/icon';

const notBlank = (control: AbstractControl) =>
  typeof control.value === 'string' && !control.value.trim()
    ? { blank: true }
    : null;

export function institutionalEmail(control: AbstractControl) {
  if (!control.value) return null;

  if (!/^(admin|operador)\.[a-z]+$/.test(control.value)) {
    return { institutional: true };
  }

  const role = control.parent?.get('rol')?.value;
  const prefix = role === 'Administrador' ? 'admin.' : 'operador.';

  return role && !control.value.startsWith(prefix)
    ? { roleEmail: true }
    : null;
}

@Component({
  selector: 'iw-user-form',
  imports: [
    ReactiveFormsModule,
    RouterLink,
    MatButtonModule,
    MatFormFieldModule,
    MatInputModule,
    Icon,
  ],
  templateUrl: './user-form.html',
})
export class UserForm implements PendingChanges {
  private readonly users = inject(UsersService);
  private readonly auth = inject(AuthService);
  private readonly notice = inject(NoticeService);
  private readonly router = inject(Router);
  private readonly dialog = inject(MatDialog);
  private readonly element =
    viewChild<ElementRef<HTMLFormElement>>('userForm');

  readonly rawId = inject(ActivatedRoute).snapshot.paramMap.get('id');
  readonly id = this.rawId === null ? undefined : Number(this.rawId);

  readonly invalidId =
    this.rawId !== null &&
    (!Number.isInteger(this.id) || (this.id as number) <= 0);

  readonly form = inject(FormBuilder).nonNullable.group({
    nomUsuario: [
      '',
      [Validators.required, notBlank, Validators.maxLength(50)],
    ],
    correo: [
      '',
      [
        Validators.required,
        institutionalEmail,
        Validators.maxLength(88),
      ],
    ],
    contrasena: [
      '',
      [Validators.minLength(6), Validators.maxLength(20)],
    ],
    rol: ['Operador de Almacén' as Rol, Validators.required],
    telefono: [
      '',
      [
        Validators.maxLength(15),
        Validators.pattern(/^[0-9]*[1-9][0-9]*$/),
      ],
    ],
  });

  readonly busy = signal(false);
  readonly loading = signal(this.rawId !== null && !this.invalidId);
  readonly error = signal('');
  readonly loadError = signal(
    this.invalidId ? 'El identificador del usuario no es válido.' : '',
  );
  readonly showPassword = signal(false);

  readonly errorText = (
    control: AbstractControl,
    label: string,
  ): string => {
    if (control.hasError('institutional')) {
      return 'Usa admin.nombre u operador.nombre, solo con letras minúsculas.';
    }

    if (control.hasError('roleEmail')) {
      return 'El correo no coincide con el rol seleccionado. Revisa el prefijo admin u operador.';
    }

    if (
      control === this.form.controls.telefono &&
      control.hasError('pattern')
    ) {
      return 'Ingresa solo números; el teléfono debe ser mayor que cero.';
    }

    return fieldError(control, label);
  };

  onlyPhoneDigits(event: Event): void {
    const input = event.target as HTMLInputElement;
    const digits = input.value.replace(/[^0-9]/g, '');

    if (input.value !== digits) {
      input.value = digits;
      this.form.controls.telefono.setValue(digits);
    }
  }

  constructor() {
    this.form.controls.rol.valueChanges
      .pipe(takeUntilDestroyed())
      .subscribe(() => {
        this.form.controls.correo.updateValueAndValidity();
        this.form.controls.correo.markAsTouched();
      });

    if (this.rawId === null) {
      this.form.controls.contrasena.addValidators([
        Validators.required,
        notBlank,
      ]);
    } else if (!this.invalidId) {
      void this.load();
    }
  }

  async load(): Promise<void> {
    if (this.invalidId) return;

    this.loading.set(true);
    this.loadError.set('');

    try {
      const user = await this.users.get(this.id!);

      this.form.patchValue({
        ...user,
        correo: user.correo.replace(/@intiwasi\.pe$/, ''),
        telefono: user.telefono ?? '',
        contrasena: '',
      });

      this.form.controls.correo.updateValueAndValidity();
      this.form.markAsPristine();
    } catch (error) {
      this.loadError.set(
        error instanceof Error
          ? error.message
          : 'No se pudo cargar el usuario.',
      );
    } finally {
      this.loading.set(false);
    }
  }

  async submit(): Promise<void> {
    if (this.busy() || this.loading() || this.loadError()) return;

    this.error.set('');
    this.form.markAllAsTouched();

    if (this.form.invalid) {
      focusFirstInvalid(this.element()!.nativeElement);
      return;
    }

    this.busy.set(true);

    try {
      const value = this.form.getRawValue();

      const user = await this.users.save(
        {
          ...value,
          correo: `${value.correo}@intiwasi.pe`,
          telefono: value.telefono.trim() || null,
          contrasena: value.contrasena || undefined,
        },
        this.id,
      );

      this.form.markAsPristine();

      const current = this.auth.session();

      if (
        current?.idUsuario === user.idUsuario &&
        (current.correo !== user.correo || !!value.contrasena)
      ) {
        this.auth.logout(false, true);
        return;
      }

      this.auth.refreshUser(user);

      this.notice.showNext(
        `${user.nomUsuario}: ${
          this.id ? 'cambios guardados' : 'usuario creado correctamente'
        }.`,
      );

      // Al crear un usuario, regresar al listado de Usuarios.
      // Al editar, conservar el destino inicial del rol actualizado.
      const destination =
        this.rawId === null ? '/usuarios' : this.auth.landingRoute();

      await this.router.navigate([destination]);
    } catch (error) {
      if (
        error instanceof ApiRequestError &&
        error.field &&
        error.field in this.form.controls
      ) {
        this.form.controls[
          error.field as keyof typeof this.form.controls
        ].setErrors({
          server: error.message,
        });

        focusFirstInvalid(this.element()!.nativeElement);
      }

      this.error.set(
        error instanceof Error
          ? error.message
          : 'No se pudo guardar. Inténtalo de nuevo.',
      );
    } finally {
      this.busy.set(false);
    }
  }

  async canLeave(): Promise<boolean> {
    if (!this.auth.valid() || !this.form.dirty) return true;
    if (this.busy()) return false;

    return !!(await firstValueFrom(
      this.dialog
        .open(ConfirmDialog, {
          width: '460px',
          maxWidth: 'calc(100vw - 32px)',
          data: {
            title: '¿Salir sin guardar?',
            message:
              'Los cambios que realizaste en este formulario se perderán.',
            action: 'Salir sin guardar',
          },
        })
        .afterClosed(),
    ));
  }
}